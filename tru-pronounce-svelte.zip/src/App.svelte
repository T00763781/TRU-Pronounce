<script>
  let name = "Deiveek";
  let ipa = "ˈdeɪ.viːk";
  let syllables = ["DAY", "vik"];
</script>

<main class="frame">
  <h1>pronounce/name</h1>

  <div class="pill-row">
    <div class="pill primary">{name}</div>
    <div class="pill secondary">/{ipa}/</div>
  </div>

  <div class="syllable-row">
    {#each syllables as s}
      <div class="syllable">{s}</div>
    {/each}
    <div class="syllable add">+</div>
  </div>

  <div class="card">
    <h2>{name}</h2>
    <div class="syllable-row center">
      {#each syllables as s}
        <div class="syllable">{s}</div>
      {/each}
    </div>
    <p class="guide">Like David with a “K” instead of “D”</p>
    <p class="listen">listen at <strong>tru.ca/pronounce</strong> 🔊</p>
  </div>

  <div class="accordion">Detected Local Voice Models ▾</div>
  <div class="accordion">Cloud Models ▾</div>
  <div class="accordion">Add your voice ▾</div>

  <div class="actions">
    <button>save on device</button>
    <button>iframe</button>
    <button class="ghost">submit to library</button>
  </div>

  <footer>
    made by the<br/>
    <strong>2025–2026 Intercultural Ambassador Team</strong>
  </footer>
</main>

<style>
  :root {
    --bg: #0b3f4d;
    --bg-dark: #08323d;
    --accent: #0fb0c0;
    --accent-soft: #0aa0ae;
    --text: #ffffff;
    --muted: #cfe8ec;
  }

  body {
    margin: 0;
    font-family: Inter, system-ui, sans-serif;
    background: #000;
    display: flex;
    justify-content: center;
    padding: 2rem;
  }

  .frame {
    width: 390px;
    background: white;
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
  }

  h1 {
    color: var(--bg);
    margin-bottom: 1rem;
  }

  .pill-row {
    display: flex;
    gap: .5rem;
    justify-content: center;
    margin-bottom: .75rem;
  }

  .pill {
    padding: .5rem 1rem;
    border-radius: 999px;
    font-weight: 500;
  }

  .primary {
    background: var(--accent);
    color: white;
  }

  .secondary {
    background: var(--bg-dark);
    color: white;
  }

  .syllable-row {
    display: flex;
    justify-content: center;
    gap: .5rem;
    margin-bottom: 1rem;
  }

  .syllable {
    background: var(--accent);
    color: white;
    padding: .5rem 1rem;
    border-radius: 999px;
    font-size: .9rem;
  }

  .syllable.add {
    background: var(--bg-dark);
  }

  .card {
    background: var(--bg);
    color: white;
    border-radius: 16px;
    padding: 1rem;
    margin-bottom: 1rem;
  }

  .card h2 {
    margin-top: 0;
  }

  .center {
    justify-content: center;
  }

  .guide {
    margin: .75rem 0 .25rem;
  }

  .listen {
    font-size: .85rem;
    opacity: .9;
  }

  .accordion {
    background: var(--bg-dark);
    color: white;
    padding: .75rem;
    border-radius: 999px;
    margin-bottom: .5rem;
    font-size: .9rem;
  }

  .actions {
    display: flex;
    justify-content: space-between;
    gap: .5rem;
    margin: 1rem 0;
  }

  button {
    flex: 1;
    background: var(--accent);
    color: white;
    border: none;
    border-radius: 999px;
    padding: .6rem;
    font-size: .85rem;
  }

  button.ghost {
    background: var(--accent-soft);
  }

  footer {
    font-size: .75rem;
    color: #555;
  }
</style>